function submitForm() {

    let name = document.getElementById("name").value;
    let dept = document.getElementById("dept").value;
    let year = document.getElementById("year").value;
    let batch = document.getElementById("batch").value;
    let regNo = document.getElementById("regNo").value;
    let date = document.getElementById("date").value;
    let reason = document.getElementById("reason").value;

    if(name=="" || year=="" || batch=="" || regNo=="" || date=="" || reason==""){
        alert("Please fill all fields!");
        return false;
    }

    emailjs.send("service_hwyfi8i", "template_vhqirla", {
    name: "Test User",
    regNo: "12345"
});
    }).then(() => {
        alert("Sent to HOD/Tutor 📩");
        window.location.href = "thankyou.html";
    }).catch((error) => {
        alert("Email failed ❌");
        console.log(error);
    });

    return false;
}